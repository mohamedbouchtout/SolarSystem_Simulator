# PS3: N-Body Simulation

## Contact
Name: Mohamed Bouchtout
Section: 201
Time to Complete: 10 hours


## Description
Explain what the project does.
- It creates a Universe and CelestialBody classes that represent the whole universe and each planet seperetly. The classes override the draw() function that comes with the SFML library where we draw the universe then we draw each planet independantly. The input and output operators are also overloaded for both classes so you can change the data or read the data. I then implemented the step() function to add the physics to the solar system, causing it to spin at the rate and speed as it's supposed to.

### Features
Describe what your major decisions were and why you did things that way.
- A majoy decision I made is how I wanted the cunstructors to build and store the object. I made the Universe class take in the filename and extract all the data from the file. I will also create a position to scale uning the window size and radius. It then stores each CelestialBody as a shared pointer in a vector to keep track of all the pointers. 
- For part B, I decided to do all my calculations in doubles rather than float, as float was causing foat rounding errors. This helped me make the calculations at very large numbers.

### Memory
Describe how you managed the lifetimes of your objects, including if you used smart pointers.
- I used a shared pointer to manage the lifetime of the texture of the sprites for each planet.
- I then used the currentTime to keep track of the time to know when to stop the simulation.

### Issues
What did you have trouble with?  What did you learn?  What doesn't work?  Be honest.  You might be penalized if you claim something works and it doesn't.
- I had trouble deciding how I wanted to set it up and what would be the best way of going about it. I learned how to override the draw() function and how to use it from other classes. I also learned how to use smart pointers.
- Universe doesn't read the file from the command line, but rather gets passed in a filename into the constructor.

### Changes
What changes I've made for PSX.
- I changed the command line app so that the Universe object is created by reading in the file from the command line.
- I did the extra credit where it shows the elipse time. I used the sf::Font to open a font file I got from a open source GitHub, then I used the sf::Text so I can draw the time in the window. It updates the time as it loops in the while loop in the main.
- I did the extra credit where I creates a Custom Universe text file (customUniverse.txt) where I played around with the number of planets and their position, velocity and mass until I created a solar system where they orbit each other smoothly.

### Extra Credit
Anything special you did.  This is required to earn bonus points.
If you created your own universe file.  Describe it here and explain why it is interesting.
- I did the extra credit where it shows the elipse time. I used the sf::Font to open a font file I got from a open source GitHub, then I used the sf::Text so I can draw the time in the window. It updates the time as it loops in the while loop in the main.
- I did the extra credit where I creates a Custom Universe text file (customUniverse.txt) where I played around with the number of planets and their position, velocity and mass until I created a solar system where they orbit each other smoothly.

## Acknowledgements
List all sources of help including the instructor or TAs, classmates, and web pages.
If you used images or other resources than the ones provided, list them here.
- I used the activities and notes on blackboard for quidance.
- I got the backgroud picture from google and audio from YouTube.
- I got the font.ttf from a open source on GitHub.
